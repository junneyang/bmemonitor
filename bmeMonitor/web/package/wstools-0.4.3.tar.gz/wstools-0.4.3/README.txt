General
========
- Homepage:	https://github.com/pycontribs/wstools
- Mailing List:	https://groups.google.com/forum/#!forum/pycontribs
- Package:	http://pypi.python.org/pypi/wstools/
- Docs (TBD):	http://packages.python.org/wstools

Credits
========
Companies
---------
|makinacom|_

  * `Planet Makina Corpus <http://www.makina-corpus.org>`_
  * `Contact us <mailto:python@makina-corpus.org>`_

.. |makinacom| image:: http://depot.makina-corpus.org/public/logo.gif
.. _makinacom:  http://www.makina-corpus.com

Authors
------------

- Makina Corpus <python@makina-corpus.com>

Contributors
-----------------
- Sorin Sbarnea <sorin.sbarnea+os@gmail.com>

